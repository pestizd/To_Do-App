# To Do Task App

Po�tovanje

Tema moga projekta je o To Do Task App
## Recommendations

�to sam sve koristio za izradu mojega projekta

```bash
Angular,Firebase,JavaScript,Flask
```

## Usage

```python
Smisao ove aplikacije jest da si stavljate obavijesti.
Svoje taskove pi�ete u ponudeni textareabox nakon cega ga potvrdite klikom na + botun.
Nakon �to se va� task uvrstio u listu mo�ete ga oznaciti sa zelenom kvacicom da ste obradili svoj task.
Ili da ga ostavite ne oznacenoga sve dok ne ispunite svoj task.
Kada ste ispunili svoj task ili ste u slulajno postavili krivi task,desno imate ko�aricu za brisanje.
Klikom na ko�aricu va� task ce se perm izbrisati.

```
